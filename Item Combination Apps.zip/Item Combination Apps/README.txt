TUGAS BESAR AKA RPG ITEM COMBINATION APP

DESC :
Aplikasi tentang mencari kombinasi item terbaik dengan algoritma iterative dan recursive

- Ghanif Hadiyana Akbar - 103012300018
- Muhammad Alvin Ababil - 103012330064